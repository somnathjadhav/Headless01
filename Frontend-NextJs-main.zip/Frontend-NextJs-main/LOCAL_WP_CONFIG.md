# Local WordPress Configuration

## API Keys for Local WordPress (woo.local)

**Consumer Key:** `ck_8d0d21406d072c8e0159d8069c6d0b43d674983b`
**Consumer Secret:** `cs_e8e9885a66bdba3c74957cdfa146a565adec161b`

## Environment Configuration

The following environment variables are configured for local WordPress:

- `NEXT_PUBLIC_WORDPRESS_URL=https://woo.local`
- `WOOCOMMERCE_CONSUMER_KEY=ck_8d0d21406d072c8e0159d8069c6d0b43d674983b`
- `WOOCOMMERCE_CONSUMER_SECRET=cs_e8e9885a66bdba3c74957cdfa146a565adec161b`

## Usage

These keys are used to authenticate with the local WordPress WooCommerce REST API at `https://woo.local/wp-json/wc/v3/`

## Security Note

These are local development keys and should not be used in production environments.
