import { useTypography } from '../../context/TypographyContext';

export default function TypographyColorCard() {
  const { typography, loading, error } = useTypography();

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading typography & color data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div className="text-center">
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <strong>Error:</strong> {error}
          </div>
        </div>
      </div>
    );
  }

  if (!typography) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div className="text-center">
          <p className="text-gray-600">No typography data available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Typography & Color System
          </h2>
          <p className="text-lg text-gray-600">
            Complete design system with fonts, sizes, and color palette
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-sm text-gray-600">Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Typography Section */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-900">Typography</h3>
          </div>

          {/* Font Families */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Font Families</h4>
            <div className="space-y-4">
              {Object.entries(typography.fonts).map(([key, font]) => (
                <div key={key} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-gray-700 capitalize">
                        {key} Font
                      </span>
                      {font.google && (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">
                          Google
                        </span>
                      )}
                    </div>
                    <div 
                      className="text-lg text-gray-900"
                      style={{ fontFamily: `var(--font-${key})` }}
                    >
                      {font.family}
                    </div>
                    <div className="text-xs text-gray-500 font-mono">
                      {font.fallback}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Typography Scale */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Typography Scale</h4>
            <div className="space-y-3">
              {Object.entries(typography.sizes).map(([key, size]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700 uppercase tracking-wider">
                    {key}
                  </span>
                  <div className="flex items-center space-x-3">
                    <span className="text-xs text-gray-500 font-mono bg-white px-2 py-1 rounded">
                      {size}
                    </span>
                    <div 
                      className="text-gray-900"
                      style={{ fontSize: size }}
                    >
                      Aa
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sample Text */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Sample Text</h4>
            <div className="space-y-3">
              <div 
                className="text-gray-900 leading-relaxed"
                style={{
                  fontSize: `var(--body-size)`,
                  fontWeight: `var(--body-weight)`,
                  lineHeight: `var(--body-line-height)`,
                  fontFamily: `var(--font-primary)`
                }}
              >
                The quick brown fox jumps over the lazy dog. This sample text demonstrates the current typography settings.
              </div>
            </div>
          </div>
        </div>

        {/* Color Section */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-red-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zM21 5a2 2 0 00-2-2h-4a2 2 0 00-2 2v12a4 4 0 004 4h4a2 2 0 002-2V5z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-900">Color Palette</h3>
          </div>

          {/* Color Categories */}
          <div className="space-y-4">
            {Object.entries(typography.colors).map(([category, colors]) => (
              <div key={category} className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 capitalize">
                  {category} Colors
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(colors).map(([key, color]) => (
                    <div key={key} className="flex items-center space-x-3">
                      <div 
                        className="w-8 h-8 rounded-lg border-2 border-white shadow-sm"
                        style={{ backgroundColor: color }}
                        title={color}
                      ></div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 capitalize truncate">
                          {key}
                        </div>
                        <div className="text-xs text-gray-500 font-mono truncate">
                          {color}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Color Usage Examples */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Color Usage</h4>
            <div className="space-y-3">
              {typography.colors.text && (
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-6 h-6 rounded border"
                    style={{ backgroundColor: typography.colors.text.primary || '#000000' }}
                  ></div>
                  <span className="text-sm text-gray-700">Primary Text</span>
                </div>
              )}
              {typography.colors.background && (
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-6 h-6 rounded border"
                    style={{ backgroundColor: typography.colors.background.primary || '#ffffff' }}
                  ></div>
                  <span className="text-sm text-gray-700">Primary Background</span>
                </div>
              )}
              {typography.colors.accent && (
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-6 h-6 rounded border"
                    style={{ backgroundColor: typography.colors.accent.primary || '#3B82F6' }}
                  ></div>
                  <span className="text-sm text-gray-700">Accent Color</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* CSS Variables Reference */}
      <div className="mt-8 pt-6 border-t border-gray-200">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">CSS Variables Available</h4>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 text-sm mb-3">
            All typography and color settings are available as CSS custom properties:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div>
              <div className="text-blue-900 font-semibold mb-2">Typography:</div>
              <div className="space-y-1 text-blue-700">
                <div>--font-primary</div>
                <div>--font-secondary</div>
                <div>--text-base, --text-lg, etc.</div>
                <div>--heading-h1-size, --heading-h1-weight</div>
                <div>--body-size, --body-weight</div>
              </div>
            </div>
            <div>
              <div className="text-blue-900 font-semibold mb-2">Colors:</div>
              <div className="space-y-1 text-blue-700">
                <div>--color-text-primary</div>
                <div>--color-background-primary</div>
                <div>--color-accent-primary</div>
                <div>--color-headings-primary</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

